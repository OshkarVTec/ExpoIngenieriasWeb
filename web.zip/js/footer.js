/*FUNCIONES FOOTER*/

function redireccionFacebook() {
  location.href = "https://www.facebook.com/escueladeingenieriaycienciaspuebla";
}

function redireccionIG() {
  location.href = "https://www.instagram.com/ingenieriaspue";
}

function redireccionLogo() {
  location.href = "index.html";
}
